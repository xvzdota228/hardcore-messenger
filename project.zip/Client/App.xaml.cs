using System.Windows;

namespace HardcoreMessenger
{
    public partial class App : Application
    {
    }
}
